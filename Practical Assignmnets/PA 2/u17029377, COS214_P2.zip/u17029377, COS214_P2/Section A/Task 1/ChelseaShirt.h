#ifndef CHELSEASHIRT_H
#define CHELSEASHIRT_H

#include "Shirt.h"

class ChelseaShirt : public Shirt
{
private:
    /* data */
public:
    ChelseaShirt(/* args */);
    ChelseaShirt(string n);
    ~ChelseaShirt();
};
#endif
