#ifndef LIVERPOOLSOCCERBALL_H
#define LIVERPOOLSOCCERBALL_H

#include "SoccerBall.h"

class LiverpoolSoccerBall : public SoccerBall
{
private:
    /* data */
public:
    LiverpoolSoccerBall(/* args */);
    LiverpoolSoccerBall(string i);
    ~LiverpoolSoccerBall();
};
#endif
