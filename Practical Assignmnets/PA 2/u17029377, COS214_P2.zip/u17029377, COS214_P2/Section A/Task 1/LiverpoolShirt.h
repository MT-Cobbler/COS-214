#ifndef LIVERPOOLSHIRT_H
#define LIVERPOOLSHIRT_H

#include "Shirt.h"

class LiverpoolShirt : public Shirt
{
private:
    /* data */
public:
    LiverpoolShirt(/* args */);
    LiverpoolShirt(string n);
    ~LiverpoolShirt();
};
#endif
