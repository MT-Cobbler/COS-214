#ifndef ARSENALSHIRT_H
#define ARSENALSHIRT_H

#include "Shirt.h"

class ArsenalShirt : public Shirt
{
private:
    /* data */
public:
    ArsenalShirt(/* args */);
    ArsenalShirt(string n);
    ~ArsenalShirt();
};
#endif
