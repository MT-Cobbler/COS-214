#include "MerchandiseFactory.h"

MerchandiseFactory::MerchandiseFactory(){
    // cout << "MerchandiseFacrory Constructor" << endl;
}

MerchandiseFactory::~MerchandiseFactory(){
    // cout << "MerchandiseFacrory Destructor" << endl;
}
