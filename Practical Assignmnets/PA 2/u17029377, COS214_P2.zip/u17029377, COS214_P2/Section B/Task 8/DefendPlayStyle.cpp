#include "DefendPlayStyle.h"

DefendPlayStyle::DefendPlayStyle(){}

DefendPlayStyle::~DefendPlayStyle(){}

string DefendPlayStyle::play(){
    return "is defending their team's half of the field.";
}
string DefendPlayStyle::getStyle(){
    return "Defender";
}