#include "AttackPlayStyle.h"

AttackPlayStyle::AttackPlayStyle(){}

AttackPlayStyle::~AttackPlayStyle(){}

string AttackPlayStyle::play(){
    return "is attacking the opposition's goal with the ball.";
}
string AttackPlayStyle::getStyle(){
    return "Attacker";
}