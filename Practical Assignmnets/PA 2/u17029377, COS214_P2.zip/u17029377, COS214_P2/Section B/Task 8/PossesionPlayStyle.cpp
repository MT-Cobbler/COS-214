#include "PossesionPlayStyle.h"

PossesionPlayStyle::PossesionPlayStyle(){}

PossesionPlayStyle::~PossesionPlayStyle(){}

string PossesionPlayStyle::play(){
    return  "is helping their team keep possesion of the ball by passing it to their teammates.";
}
string PossesionPlayStyle::getStyle(){
    return "Midfielder";
}