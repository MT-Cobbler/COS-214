#include "CardState.h"

CardState::CardState(){}

string CardState::getCardColour(){
    return this->cardColour;
}
CardState::~CardState(){}