#ifndef SOCCERPLAYER_H
#define SOCCERPLAYER_H
#include "CardState.h"
#include "NoCardState.h"
#include "YellowCardState.h"
#include "RedCardState.h"
#include <iostream>
using namespace std;

class SoccerPlayer{
    private:
        string name;
        CardState* card_;
    public:
        SoccerPlayer();
        SoccerPlayer(string n);
        ~SoccerPlayer();
        void commitFoul(); // change the card state
        string getName();
};
#endif
