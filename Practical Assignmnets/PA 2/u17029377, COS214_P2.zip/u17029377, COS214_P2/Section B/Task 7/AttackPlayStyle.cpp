#include "AttackPlayStyle.h"

AttackPlayStyle::AttackPlayStyle(){}

AttackPlayStyle::~AttackPlayStyle(){}

string AttackPlayStyle::play(){
    return "is attacking the oppositin's goal with the ball.";
}