#include "PlayStyle.h"

PlayStyle::PlayStyle(){

}
PlayStyle::~PlayStyle(){}
