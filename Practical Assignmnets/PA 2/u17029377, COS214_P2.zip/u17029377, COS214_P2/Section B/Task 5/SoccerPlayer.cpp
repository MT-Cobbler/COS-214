#include "SoccerPlayer.h"

SoccerPlayer::SoccerPlayer(){
    cout << "SoccerPlayer Created" << endl;
}
