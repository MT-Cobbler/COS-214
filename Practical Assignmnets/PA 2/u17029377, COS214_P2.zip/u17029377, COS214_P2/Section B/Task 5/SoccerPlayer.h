#ifndef SOCCERPLAYER_H
#define SOCCERPLAYER_H

#include <iostream>
using namespace std;

class SoccerPlayer{
    private:
        string name;
    public:
        SoccerPlayer();
};
#endif