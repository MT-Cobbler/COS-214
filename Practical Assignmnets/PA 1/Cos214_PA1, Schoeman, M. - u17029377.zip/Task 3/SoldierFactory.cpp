#include "SoldierFactory.h"
SoldierFactory::SoldierFactory(/* args */)
{
}

SoldierFactory::~SoldierFactory()
{
}

