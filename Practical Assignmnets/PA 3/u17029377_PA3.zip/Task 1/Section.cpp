#include "Section.h"

Section::Section(){}
Section::~Section(){}
void Section::add(Section *){}
void Section::remove(){}