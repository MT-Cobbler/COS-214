#include "Straight.h"


Straight::Straight(){}
Straight::~Straight(){}
void Straight::print(){
    cout << "Stright" << endl;
}