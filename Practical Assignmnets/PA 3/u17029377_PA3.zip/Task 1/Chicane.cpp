#include "Chicane.h"

Chicane::Chicane(){}
Chicane::~Chicane(){}
void Chicane::print(){
    cout << "Chicane" << endl;
}