#ifndef CHICANE_H
#define CHICANE_H

#include "Section.h"

class Chicane : public Section{
    public:
        Chicane();
        ~Chicane();
        void print();
};
#endif
