#ifndef STRAIGHT_H
#define STRAIGHT_H

#include "Section.h"
using namespace std;

class Straight : public Section{
    public:
        Straight();
        ~Straight();
        void print();
};
#endif
