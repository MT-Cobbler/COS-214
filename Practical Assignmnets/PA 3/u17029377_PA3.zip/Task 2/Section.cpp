#include "Section.h"

Section::Section(){}
Section::~Section(){}

void Section::add(Section *s){
}
void Section::remove(){}