#include "Straight.h"


Straight::Straight(){}
Straight::~Straight(){}
void Straight::print(){
    cout << endl;
    cout << "\tStright \t";
}