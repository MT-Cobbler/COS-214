#include "GravelTrap.h"

GravelTrap::GravelTrap(){}
GravelTrap::~GravelTrap(){}
void GravelTrap::print(){
    Decorator::print();
    cout << "Gravel traps";
}