#include "Engineer.h"

Engineer::Engineer(){
    // cout << "Engineer: ";
}

Engineer::~Engineer(){}