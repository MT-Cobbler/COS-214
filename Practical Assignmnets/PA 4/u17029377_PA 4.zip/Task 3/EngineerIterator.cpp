#include "EngineerIterator.h"

EngineerIterator::EngineerIterator(){}
EngineerIterator::~EngineerIterator(){}