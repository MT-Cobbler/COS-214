#include "CoreIterator.h"
#include "OperationsIterator.h"
#include "ListOfCore.h"
#include "EngineerCollection.h"
#include "CSCoreEngineer.h"

#include <iostream>

using namespace std;

int main(){
    cout << "I did not manage to do 3.3 and the scenario" << endl;
    return 0;
}