#include "BooleanExpression.h"

BooleanExpression::BooleanExpression(void)
{
}

BooleanExpression::~BooleanExpression(void)
{
}
